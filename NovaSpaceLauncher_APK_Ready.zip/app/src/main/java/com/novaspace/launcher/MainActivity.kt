package com.novaspace.launcher

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.detectDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class SpaceConfig(
    val fontSize: Float = 20f,
    val clockSize: Float = 46f,
    val horizontalPadding: Float = 22f,
    val background: Int = 0xFF101010.toInt()
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NovaSpaceApp() }
    }
}

@Composable
fun NovaSpaceApp() {
    val context = LocalContext.current
    var query by remember { mutableStateOf("") }
    var editor by remember { mutableStateOf(false) }
    var dark by remember { mutableStateOf(true) }
    var fontSize by remember { mutableFloatStateOf(20f) }
    var clockSize by remember { mutableFloatStateOf(46f) }
    var padding by remember { mutableFloatStateOf(22f) }
    var spaceName by remember { mutableStateOf("HOME") }
    var activeTab by remember { mutableStateOf(0) }

    val apps = remember {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        context.packageManager.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(context.packageManager).toString().lowercase() }
    }

    val filtered = apps.filter {
        it.loadLabel(context.packageManager).toString().contains(query, true)
    }

    val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
    val date = SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date())

    MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
        Box(
            Modifier.fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(horizontal = padding.dp, vertical = 28.dp)
        ) {
            Column(Modifier.fillMaxSize()) {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Column {
                        Text(time, fontSize = clockSize.sp, fontWeight = FontWeight.Light)
                        Text(date.replaceFirstChar { it.uppercase() }, fontSize = 13.sp)
                        Text(spaceName, fontSize = 10.sp, letterSpacing = 4.sp)
                    }
                    TextButton(onClick = { editor = !editor }) {
                        Text(if (editor) "DONE" else "EDIT")
                    }
                }

                Spacer(Modifier.height(20.dp))

                if (editor) {
                    EditorPanel(
                        fontSize = fontSize,
                        clockSize = clockSize,
                        padding = padding,
                        onFontChange = { fontSize = it },
                        onClockChange = { clockSize = it },
                        onPaddingChange = { padding = it },
                        dark = dark,
                        onDarkChange = { dark = it },
                        spaceName = spaceName,
                        onSpaceName = { spaceName = it }
                    )
                    Spacer(Modifier.height(14.dp))
                }

                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    placeholder = { Text("Search applications") },
                    shape = RoundedCornerShape(20.dp)
                )

                Spacer(Modifier.height(8.dp))

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(1.dp)
                ) {
                    items(filtered) { info ->
                        val name = info.loadLabel(context.packageManager).toString()
                        Text(
                            name,
                            modifier = Modifier.fillMaxWidth()
                                .clickable {
                                    val launch = context.packageManager
                                        .getLaunchIntentForPackage(info.activityInfo.packageName)
                                    if (launch != null) context.startActivity(launch)
                                }
                                .padding(vertical = 7.dp),
                            fontSize = fontSize.sp
                        )
                    }
                }

                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    TextButton(onClick = { activeTab = 0; spaceName = "HOME" }) { Text("HOME") }
                    TextButton(onClick = { activeTab = 1; spaceName = "WORK" }) { Text("WORK") }
                    TextButton(onClick = { activeTab = 2; spaceName = "GAMES" }) { Text("GAMES") }
                }
            }
        }
    }
}

@Composable
fun EditorPanel(
    fontSize: Float,
    clockSize: Float,
    padding: Float,
    onFontChange: (Float) -> Unit,
    onClockChange: (Float) -> Unit,
    onPaddingChange: (Float) -> Unit,
    dark: Boolean,
    onDarkChange: (Boolean) -> Unit,
    spaceName: String,
    onSpaceName: (String) -> Unit
) {
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Text("SPACE DESIGNER", fontWeight = FontWeight.Bold)
            Text("Настрой внешний вид пространства")

            Spacer(Modifier.height(6.dp))
            Text("Размер текста: ${fontSize.toInt()}sp")
            Slider(value = fontSize, onValueChange = onFontChange, valueRange = 14f..32f)

            Text("Размер часов: ${clockSize.toInt()}sp")
            Slider(value = clockSize, onValueChange = onClockChange, valueRange = 28f..72f)

            Text("Отступы: ${padding.toInt()}dp")
            Slider(value = padding, onValueChange = onPaddingChange, valueRange = 8f..40f)

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Тёмная тема")
                Spacer(Modifier.weight(1f))
                Switch(checked = dark, onCheckedChange = onDarkChange)
            }

            OutlinedTextField(
                value = spaceName,
                onValueChange = onSpaceName,
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("Название пространства") }
            )
        }
    }
}
